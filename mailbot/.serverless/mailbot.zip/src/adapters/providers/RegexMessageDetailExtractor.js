"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegexMessageDetailExtractor = void 0;
const DomainResult_1 = require("src/core/domain/common/DomainResult");
class RegexMessageDetailExtractor {
    extract(crawler, message) {
        const data = {};
        for (const o of crawler.getProviderPattern()) {
            const r = new RegExp(o.getPattern(), "m");
            const t = message.getBody().match(r);
            if (t?.groups?.v == undefined) {
                return DomainResult_1.DomainResult.Error(new Error(`${message.getId()} doesn't match pattern: ${o.getPattern()}`));
            }
            data[o.getProperty()] = t.groups.v;
        }
        return DomainResult_1.DomainResult.Ok(data);
    }
}
exports.RegexMessageDetailExtractor = RegexMessageDetailExtractor;
