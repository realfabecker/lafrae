"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SQSQueueProvider = void 0;
const client_sqs_1 = require("@aws-sdk/client-sqs");
const DomainResult_1 = require("src/core/domain/common/DomainResult");
class SQSQueueProvider {
    queueUrl;
    client;
    constructor(queueUrl) {
        this.queueUrl = queueUrl;
        let config = {
            region: "us-east-1",
        };
        if (process.env.AWS_ENDPOINT) {
            config = {
                ...config,
                endpoint: process.env.AWS_ENDPOINT,
            };
        }
        this.client = new client_sqs_1.SQSClient(config);
    }
    async publish(message) {
        try {
            const command = new client_sqs_1.SendMessageCommand({
                QueueUrl: this.queueUrl,
                MessageBody: JSON.stringify(message),
            });
            await this.client.send(command);
            return DomainResult_1.DomainResult.Ok();
        }
        catch (e) {
            return DomainResult_1.DomainResult.Error(e);
        }
    }
}
exports.SQSQueueProvider = SQSQueueProvider;
