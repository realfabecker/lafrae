"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleEmailMessageProvider = void 0;
const EmailMessageMapper_1 = require("src/adapters/mappers/EmailMessageMapper");
const ErrorResultMapper_1 = require("src/adapters/mappers/ErrorResultMapper");
const axios_1 = __importDefault(require("axios"));
const DomainResult_1 = require("src/core/domain/common/DomainResult");
class GoogleEmailMessageProvider {
    accessToken;
    client;
    constructor(accessToken) {
        this.accessToken = accessToken;
        this.client = axios_1.default.create({
            baseURL: "https://gmail.googleapis.com",
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
    }
    async getAttachment(messageId, attachmentId) {
        try {
            const response = await this.client.get(`/gmail/v1/users/me/messages/${messageId}/attachments/${attachmentId}`);
            return DomainResult_1.DomainResult.Ok(response.data.data);
        }
        catch (e) {
            return ErrorResultMapper_1.ErrorResultMapper.fromGoogle(e.response?.data?.error);
        }
    }
    async getMessage(messageId) {
        try {
            const response = await this.client.get(`/gmail/v1/users/me/messages/${messageId}`);
            return DomainResult_1.DomainResult.Ok(EmailMessageMapper_1.EmailMessageMapper.fromGoogle(response.data));
        }
        catch (e) {
            return ErrorResultMapper_1.ErrorResultMapper.fromGoogle(e.response?.data?.error);
        }
    }
    async listUnread(filter) {
        try {
            let q = [];
            q.push("is:unread");
            if (filter.getLabel()) {
                q.push(`label:${filter.getLabel()}`);
            }
            const response = await this.client.get("/gmail/v1/users/me/messages", {
                params: { q: q.join(" ") },
            });
            const messages = (response.data?.messages ?? []).map((item) => EmailMessageMapper_1.EmailMessageMapper.fromGoogle(item));
            return DomainResult_1.DomainResult.Ok(messages);
        }
        catch (e) {
            return ErrorResultMapper_1.ErrorResultMapper.fromGoogle(e.response?.data?.error);
        }
    }
    async markAsRead(messageId) {
        try {
            await this.client.post(`/gmail/v1/users/me/messages/${messageId}/modify`, {
                removeLabelIds: ["UNREAD"],
            });
            return DomainResult_1.DomainResult.Ok();
        }
        catch (e) {
            return ErrorResultMapper_1.ErrorResultMapper.fromGoogle(e.response?.data?.error);
        }
    }
}
exports.GoogleEmailMessageProvider = GoogleEmailMessageProvider;
