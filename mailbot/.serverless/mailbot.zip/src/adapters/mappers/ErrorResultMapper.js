"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorResultMapper = void 0;
const DomainError_1 = require("src/core/domain/common/DomainError");
const DomainResult_1 = require("src/core/domain/common/DomainResult");
class ErrorResultMapper {
    static fromGoogle(error) {
        const domainResult = new DomainResult_1.DomainResult();
        const domainError = new DomainError_1.DomainError();
        domainError.setStatusCode(error?.code);
        domainError.setError(error?.message);
        domainResult.setError(domainError);
        return domainResult;
    }
}
exports.ErrorResultMapper = ErrorResultMapper;
