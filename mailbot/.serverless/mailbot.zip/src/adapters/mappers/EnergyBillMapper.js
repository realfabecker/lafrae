"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnergyBillMapper = void 0;
const EnergyBill_1 = require("src/core/domain/invoices/EnergyBill");
const EnergyBill_2 = require("src/database/dynamodb/entities/EnergyBill");
const Attachment_1 = require("src/core/domain/invoices/Attachment");
const date_fns_1 = require("date-fns");
const uuid_1 = require("uuid");
const MessageType_1 = require("src/core/domain/enums/MessageType");
const node_crypto_1 = __importDefault(require("node:crypto"));
class EnergyBillMapper {
    static fromPayload(emailMessage, userId, details) {
        const energyBill = new EnergyBill_1.EnergyBill({
            userId: userId,
            id: (0, uuid_1.v7)(),
            externalId: emailMessage.getId(),
            consumption: Number(details.consumption.replaceAll(/\D+/g, "")),
            createdAt: new Date(),
            days: Number(details.days),
            dueDate: (0, date_fns_1.parse)(details.dueDate, "dd/MM/yyyy", new Date()),
            messageType: MessageType_1.MessageType.EnergyBill,
            reference: details.reference,
            total: Number(details.total.replace(",", ".")),
        });
        for (const attachment of emailMessage.getAttachment()) {
            const invoiceAttachment = new Attachment_1.Attachment({
                id: node_crypto_1.default.randomUUID(),
                externalId: attachment.getId(),
                name: attachment.getName(),
                contentEncoding: attachment.getContentEncoding(),
                contentType: attachment.getContentType(),
                userId: userId,
                createdAt: new Date(),
            });
            energyBill.addAttachment(invoiceAttachment);
        }
        return energyBill;
    }
    static fromPersistence(energyBill) {
        const model = new EnergyBill_1.EnergyBill({
            userId: energyBill.UserId,
            id: energyBill.ID,
            externalId: energyBill.ExternalId,
            consumption: Number(energyBill.Consumption),
            createdAt: (0, date_fns_1.parseISO)(energyBill.CreatedAt),
            days: Number(energyBill.Days),
            dueDate: (0, date_fns_1.parseISO)(energyBill.DueDate),
            messageType: energyBill.MessageType,
            reference: energyBill.Reference,
            total: Number(energyBill.Total),
        });
        for (const attachment of energyBill.Attachments) {
            const invoiceAttachment = new Attachment_1.Attachment(attachment);
            model.addAttachment(invoiceAttachment);
        }
        return model;
    }
    static toPersistence(energyBill) {
        return new EnergyBill_2.EnergyBill({
            PK: `app#mailbot#user#${energyBill.getUserId()}`,
            SK: `message#${energyBill.getId()}`,
            ID: energyBill.getId(),
            ExternalId: energyBill.getExternalId(),
            UserId: energyBill.getUserId(),
            Reference: energyBill.getReference(),
            Consumption: `${energyBill.getConsumption()}`,
            Days: energyBill.getDays(),
            CreatedAt: energyBill.getCreatedAt().toISOString(),
            DueDate: energyBill.getDueDate().toISOString(),
            GSI1_PK: `app#mailbot#user#${energyBill.getUserId()}`,
            GSI1_SK: `message_type#${energyBill.getMessageType()}`,
            Total: energyBill.getTotal(),
            MessageType: energyBill.getMessageType(),
            Attachments: energyBill.getAttachment().map((x) => x.serialize()),
        });
    }
}
exports.EnergyBillMapper = EnergyBillMapper;
