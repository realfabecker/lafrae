"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailMessageMapper = void 0;
const EmailAttachment_1 = require("src/core/domain/email/EmailAttachment");
const EmailMessage_1 = require("src/core/domain/email/EmailMessage");
class EmailMessageMapper {
    static fromGoogle(message) {
        let emailBody;
        if (message?.payload?.parts) {
            const emailBodyB64 = (message?.payload?.parts || [])
                .filter((p) => p.mimeType === "multipart/alternative")[0]
                .parts.filter((p) => p.mimeType === "text/plain")[0].body.data;
            if (emailBodyB64) {
                emailBody = Buffer.from(emailBodyB64, "base64").toString("utf8");
            }
        }
        let attachments = [];
        if (message?.payload?.parts) {
            attachments = message.payload.parts
                .filter((p) => p.mimeType === "application/pdf")
                .map((a) => {
                return new EmailAttachment_1.EmailAttachment({
                    id: a.body.attachmentId,
                    name: a.filename,
                    contentEncoding: "base64",
                    contentType: "application/pdf",
                });
            });
        }
        return new EmailMessage_1.EmailMessage({
            id: message.id,
            body: emailBody,
            attachment: attachments,
        });
    }
}
exports.EmailMessageMapper = EmailMessageMapper;
