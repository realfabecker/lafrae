"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImportMessageAttachment = void 0;
const DomainResult_1 = require("src/core/domain/common/DomainResult");
class ImportMessageAttachment {
    emailProvider;
    energyBillRepository;
    objectStorageRepository;
    logger;
    constructor(emailProvider, energyBillRepository, objectStorageRepository, logger) {
        this.emailProvider = emailProvider;
        this.energyBillRepository = energyBillRepository;
        this.objectStorageRepository = objectStorageRepository;
        this.logger = logger;
    }
    async run({ userId, messageId, }) {
        const fetchMessageResult = await this.energyBillRepository.findById(userId, messageId);
        if (!fetchMessageResult.getPayload()) {
            return DomainResult_1.DomainResult.Error(new Error(`msg ${messageId} not exists`));
        }
        if (!fetchMessageResult.getPayload()?.getAttachment()?.length) {
            this.logger.info(`msg ${messageId} has no attachs`);
            return DomainResult_1.DomainResult.Ok();
        }
        return this.processAttachments(fetchMessageResult.getPayload());
    }
    async processAttachments(energyBill) {
        for (const attachment of energyBill.getAttachment()) {
            const fetchAndSaveResult = await this.fetchAndSaveAttachment(energyBill.getExternalId(), attachment);
            if (!fetchAndSaveResult.isSuccess()) {
                return fetchAndSaveResult;
            }
        }
        return DomainResult_1.DomainResult.Ok();
    }
    async fetchAndSaveAttachment(externalId, attachment) {
        const getAttachmentResult = await this.emailProvider.getAttachment(externalId, attachment.getExternalId());
        if (!getAttachmentResult.isSuccess()) {
            return getAttachmentResult;
        }
        return this.objectStorageRepository.upload({
            key: attachment.getObjectUrl(),
            content: getAttachmentResult.getPayload(),
            contentEncoding: attachment.getContentEncoding(),
            contentType: attachment.getContentType(),
        });
    }
}
exports.ImportMessageAttachment = ImportMessageAttachment;
