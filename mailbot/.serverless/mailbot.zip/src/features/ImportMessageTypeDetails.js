"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImportMessageTypeDetails = void 0;
const EnergyBillMapper_1 = require("src/adapters/mappers/EnergyBillMapper");
const DomainResult_1 = require("src/core/domain/common/DomainResult");
const CrawlerDoesNotExists_1 = require("src/core/domain/errors/CrawlerDoesNotExists");
const NotEnoughMessageDetails_1 = require("src/core/domain/errors/NotEnoughMessageDetails");
class ImportMessageTypeDetails {
    opts;
    constructor(opts) {
        this.opts = opts;
    }
    async run({ userId, crawlerId, messageId, }) {
        const crawler = await this.opts.crawlerRepository.getCrawler(crawlerId);
        if (!crawler) {
            return DomainResult_1.DomainResult.Error(new CrawlerDoesNotExists_1.CrawlerDoesNotExists(crawlerId));
        }
        const getEmailMessage = await this.opts.emailProvider.getMessage(messageId);
        if (!getEmailMessage.isSuccess())
            return getEmailMessage;
        const extractDetails = this.opts.detailExtractor.extract(crawler, getEmailMessage.getPayload());
        if (!extractDetails.isSuccess()) {
            return DomainResult_1.DomainResult.Error(new NotEnoughMessageDetails_1.NotEnoughtMessageDetails(messageId));
        }
        const energyBill = EnergyBillMapper_1.EnergyBillMapper.fromPayload(getEmailMessage.getPayload(), userId, extractDetails.getPayload());
        if (!Object.keys(energyBill)) {
            return DomainResult_1.DomainResult.Error(new NotEnoughMessageDetails_1.NotEnoughtMessageDetails(messageId));
        }
        const saveEnegyBil = await this.opts.energyBillRepository.save(energyBill);
        if (!saveEnegyBil.isSuccess())
            return saveEnegyBil;
        return this.opts.emailProvider.markAsRead(messageId);
    }
}
exports.ImportMessageTypeDetails = ImportMessageTypeDetails;
