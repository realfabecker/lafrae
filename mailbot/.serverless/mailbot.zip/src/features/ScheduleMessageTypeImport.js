"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScheduleMessageTypeImport = void 0;
const DomainResult_1 = require("src/core/domain/common/DomainResult");
const EmailListFilter_1 = require("src/core/domain/email/EmailListFilter");
const MessageType_1 = require("src/core/domain/enums/MessageType");
const CrawlerDoesNotExists_1 = require("src/core/domain/errors/CrawlerDoesNotExists");
class ScheduleMessageTypeImport {
    opts;
    constructor(opts) {
        this.opts = opts;
    }
    async run(crawlerId) {
        const crawler = await this.opts.crawlerRepository.getCrawler(crawlerId);
        if (!crawler) {
            return DomainResult_1.DomainResult.Error(new CrawlerDoesNotExists_1.CrawlerDoesNotExists(crawlerId));
        }
        const filter = new EmailListFilter_1.EmailListFilter({ label: crawler.getProviderFilter() });
        const messagesResult = await this.opts.emailProvider.listUnread(filter);
        if (!messagesResult.isSuccess()) {
            return DomainResult_1.DomainResult.Error(new Error("não foi possível obter mensagens"));
        }
        if (!messagesResult.getPayload()?.length) {
            this.opts.logger.info("não há mensagens para o filtro");
            return DomainResult_1.DomainResult.Ok();
        }
        return this.schedule(messagesResult.getPayload() ?? []);
    }
    async schedule(messages) {
        for (const message of messages) {
            this.opts.logger.info(`schedule mensagem ${message.getId()}`);
            await this.opts.queueProvider.publish({
                meta: {
                    type: `message_type#${MessageType_1.MessageType.EnergyBill}`,
                },
                data: {
                    messageId: message.getId(),
                },
            });
        }
        return DomainResult_1.DomainResult.Ok();
    }
}
exports.ScheduleMessageTypeImport = ScheduleMessageTypeImport;
