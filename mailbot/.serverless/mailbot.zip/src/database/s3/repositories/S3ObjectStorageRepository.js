"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3ObjectStorageRepository = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const DomainResult_1 = require("src/core/domain/common/DomainResult");
const UnabletToUploadObject_1 = require("src/core/domain/errors/UnabletToUploadObject");
class S3ObjectStorageRepository {
    async upload({ key, content, contentEncoding, }) {
        try {
            let config = {
                region: "us-east-1",
            };
            if (process.env.AWS_ENDPOINT) {
                config = {
                    ...config,
                    endpoint: process.env.AWS_ENDPOINT,
                    forcePathStyle: true,
                };
            }
            const client = new client_s3_1.S3Client(config);
            const command = new client_s3_1.PutObjectCommand({
                Bucket: "sintese",
                Key: key,
                Body: Buffer.from(content, contentEncoding),
                ContentEncoding: contentEncoding,
            });
            const result = await client.send(command);
            if (result.$metadata.httpStatusCode !== 200) {
                return DomainResult_1.DomainResult.Error(new UnabletToUploadObject_1.UnableToUploadObject());
            }
            return DomainResult_1.DomainResult.Ok(key);
        }
        catch (e) {
            return DomainResult_1.DomainResult.Error(e);
        }
    }
}
exports.S3ObjectStorageRepository = S3ObjectStorageRepository;
