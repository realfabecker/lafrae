"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnergyBill = void 0;
const AbstractModel_1 = require("src/core/domain/common/AbstractModel");
class EnergyBill extends AbstractModel_1.AbstractModel {
    constructor(opts) {
        super(opts);
    }
    getPK() {
        return this.get("PK");
    }
    setPK(pk) {
        this.set("PK", pk);
    }
    getSK() {
        return this.get("SK");
    }
    setSK(sk) {
        this.set("SK", sk);
    }
    getGSI1PK() {
        return this.get("GSI1_PK");
    }
    setGSI1PK(gsi1_pk) {
        this.set("GSI1_PK", gsi1_pk);
    }
    getGSI1SK() {
        return this.get("GSI1_SK");
    }
    setGSI1SK(gsi1_sk) {
        this.set("GSI1_SK", gsi1_sk);
    }
    getTotal() {
        return this.get("Total");
    }
    setTotal(total) {
        this.set("Total", total);
    }
    getDueDate() {
        return this.get("DueDate");
    }
    setDueDate(dueDate) {
        this.set("DueDate", dueDate);
    }
    getDays() {
        return this.get("Days");
    }
    setDays(days) {
        this.set("Days", days);
    }
    getConsumption() {
        return this.get("Consumption");
    }
    setConsumption(consumption) {
        this.set("Consumption", consumption);
    }
    getReference() {
        return this.get("Reference");
    }
    setReference(reference) {
        this.set("Reference", reference);
    }
    getID() {
        return this.get("ID");
    }
    setID(id) {
        this.set("ID", id);
    }
    getExternalId() {
        return this.get("ExternalId");
    }
    setExternalId(externalId) {
        this.set("ExternalId", externalId);
    }
    getMessageType() {
        return this.get("MessageType");
    }
    setMessageType(messageType) {
        this.set("MessageType", messageType);
    }
    getAttachments() {
        return this.get("attachments") || [];
    }
    setAttachments(attachments) {
        this.set("Attachments", attachments);
    }
    addAttachment(attachment) {
        const attachments = this.getAttachments() ?? [];
        attachments.push(attachment);
        this.setAttachments(attachments);
    }
    getUserId() {
        return this.get("UserId");
    }
    setUserId(userId) {
        this.set("UserId", userId);
    }
    getCreatedAt() {
        return this.get("CreatedAt");
    }
    setCreatedAt(createdAt) {
        this.set("CreatedAt", createdAt);
    }
}
exports.EnergyBill = EnergyBill;
