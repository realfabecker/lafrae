"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnergyBillDynamoDbRepository = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const EnergyBillMapper_1 = require("src/adapters/mappers/EnergyBillMapper");
const DomainResult_1 = require("src/core/domain/common/DomainResult");
const MessageAlreadyExists_1 = require("src/core/domain/errors/MessageAlreadyExists");
const UnabletToCreateInvoice_1 = require("src/core/domain/errors/UnabletToCreateInvoice");
class EnergyBillDynamoDbRepository {
    tableName;
    client;
    constructor(tableName) {
        this.tableName = tableName;
        let config = {
            region: "us-east-1",
        };
        if (process.env.AWS_ENDPOINT) {
            config = {
                ...config,
                endpoint: process.env.AWS_ENDPOINT,
            };
        }
        this.client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient(config));
    }
    async save(energyBill) {
        try {
            const message = EnergyBillMapper_1.EnergyBillMapper.toPersistence(energyBill);
            const command = new lib_dynamodb_1.TransactWriteCommand({
                TransactItems: [
                    {
                        Put: {
                            Item: message.serialize(),
                            ConditionExpression: "attribute_not_exists(PK) and attribute_not_exists(SK)",
                            TableName: this.tableName,
                        },
                    },
                    {
                        Put: {
                            Item: {
                                PK: message.getPK(),
                                SK: `message#external_id#${message.getExternalId()}`,
                                MessageSK: message.getSK(),
                            },
                            ConditionExpression: "attribute_not_exists(PK) and attribute_not_exists(SK)",
                            TableName: this.tableName,
                        },
                    },
                ],
            });
            const result = await this.client.send(command);
            if (result.$metadata.httpStatusCode !== 200) {
                return DomainResult_1.DomainResult.Error(new UnabletToCreateInvoice_1.UnableToCreateInvoice());
            }
            return DomainResult_1.DomainResult.Ok(energyBill);
        }
        catch (e) {
            if (e instanceof client_dynamodb_1.TransactionCanceledException) {
                const duplicated = e.CancellationReasons?.find((x) => x.Code === "ConditionalCheckFailed");
                if (duplicated) {
                    return DomainResult_1.DomainResult.Error(new MessageAlreadyExists_1.MessageAlreadyExists());
                }
            }
            return DomainResult_1.DomainResult.Error(e);
        }
    }
    async findById(userId, messageId) {
        try {
            const command = new lib_dynamodb_1.GetCommand({
                TableName: this.tableName,
                Key: {
                    PK: `app#mailbot#user#${userId}`,
                    SK: `message#${messageId}`,
                },
            });
            const result = await this.client.send(command);
            if (result.$metadata.httpStatusCode !== 200) {
                return DomainResult_1.DomainResult.Error(new UnabletToCreateInvoice_1.UnableToCreateInvoice());
            }
            if (!result.Item) {
                return DomainResult_1.DomainResult.Ok(null);
            }
            return DomainResult_1.DomainResult.Ok(EnergyBillMapper_1.EnergyBillMapper.fromPersistence(result.Item));
        }
        catch (e) {
            return DomainResult_1.DomainResult.Error(e);
        }
    }
    async upsertAttachments(id, attachments) {
        return DomainResult_1.DomainResult.Ok();
    }
}
exports.EnergyBillDynamoDbRepository = EnergyBillDynamoDbRepository;
