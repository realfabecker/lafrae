"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrawlerInMemRepository = void 0;
const MessageCrawler_1 = require("src/core/domain/crawler/MessageCrawler");
const ProviderPattern_1 = require("src/core/domain/crawler/ProviderPattern");
class CrawlerInMemRepository {
    async getCrawler(id) {
        const crawler = new MessageCrawler_1.MessageCrawler({
            id: "123456",
            providerFilter: "faturas-celesc",
        });
        const patterns = [
            new ProviderPattern_1.ProviderPattern({
                pattern: "Valor da fatura:\\s+R\\$\\s+(?<v>\\d+,\\d+)\r?\n",
                property: "total",
            }),
            new ProviderPattern_1.ProviderPattern({
                pattern: "Data de vencimento:\\s+(?<v>\\d+\/\\d+\/\\d+)\r?\n",
                property: "dueDate",
            }),
            new ProviderPattern_1.ProviderPattern({
                pattern: "Número de dias faturados:\\s+(?<v>\\d+)\\sdias",
                property: "days",
            }),
            new ProviderPattern_1.ProviderPattern({
                pattern: "Consumo registrado:\\s+(?<v>\\d+\\skWh)\r?\n",
                property: "consumption",
            }),
            new ProviderPattern_1.ProviderPattern({
                pattern: "Mês de referência:\\s+(?<v>\\d+\/\\d+)\r?\n",
                property: "reference",
            }),
        ];
        crawler.setProviderPattern(patterns);
        return crawler;
    }
}
exports.CrawlerInMemRepository = CrawlerInMemRepository;
