"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalObjectStorageRepository = void 0;
const node_path_1 = __importDefault(require("node:path"));
const DomainResult_1 = require("src/core/domain/common/DomainResult");
const node_fs_1 = __importDefault(require("node:fs"));
class LocalObjectStorageRepository {
    async upload({ key, content, contentEncoding, }) {
        try {
            const filename = node_path_1.default.resolve(node_path_1.default.join(__dirname, "..", "..", "..", "..", "resources", key));
            const d = node_path_1.default.dirname(filename);
            if (!node_fs_1.default.existsSync(d) && !node_fs_1.default.mkdirSync(d, { recursive: true })) {
                return DomainResult_1.DomainResult.Error(new Error("Unable to create directory"));
            }
            if (contentEncoding === "base64") {
                node_fs_1.default.writeFileSync(filename, Buffer.from(content, "base64"));
            }
            else {
                node_fs_1.default.writeFileSync(filename, content);
            }
            return DomainResult_1.DomainResult.Ok();
        }
        catch (e) {
            return DomainResult_1.DomainResult.Error(e);
        }
    }
}
exports.LocalObjectStorageRepository = LocalObjectStorageRepository;
