"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SqsAsEventSourceHandler = void 0;
class SqsAsEventSourceHandler {
    async handler(event) {
        const messages = event.Records.map((record) => record.body);
        messages.forEach((message) => console.log(message));
    }
}
exports.SqsAsEventSourceHandler = SqsAsEventSourceHandler;
