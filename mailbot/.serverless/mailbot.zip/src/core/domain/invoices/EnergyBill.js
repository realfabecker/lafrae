"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnergyBill = void 0;
const AbstractModel_1 = require("../common/AbstractModel");
class EnergyBill extends AbstractModel_1.AbstractModel {
    constructor(opts) {
        super(opts);
    }
    getId() {
        return this.get("id");
    }
    setId(id) {
        this.set("id", id);
    }
    getExternalId() {
        return this.get("externalId");
    }
    setExternalId(id) {
        this.set("externalId", id);
    }
    getTotal() {
        return this.get("total");
    }
    setTotal(total) {
        this.set("total", total);
    }
    setCreatedAt(createdAt) {
        this.set("createdAt", createdAt);
    }
    getCreatedAt() {
        return this.get("createdAt");
    }
    getDueDate() {
        return this.get("dueDate");
    }
    setDueDate(dueDate) {
        this.set("dueDate", dueDate);
    }
    getDays() {
        return this.get("days");
    }
    setDays(days) {
        this.set("days", days);
    }
    getConsumption() {
        return this.get("consumption");
    }
    setConsumption(consumption) {
        this.set("consumption", consumption);
    }
    getReference() {
        return this.get("reference");
    }
    setReference(reference) {
        this.set("reference", reference);
    }
    getUserId() {
        return this.get("userId");
    }
    setUserId(userId) {
        this.set("userId", userId);
    }
    getMessageType() {
        return this.get("messageType");
    }
    setMessageType(messageType) {
        this.set("messageType", messageType);
    }
    getAttachment() {
        return this.get("attachment") || [];
    }
    setAttachment(attachment) {
        this.set("attachment", attachment);
    }
    addAttachment(attachment) {
        const attachments = this.getAttachment() ?? [];
        attachments.push(attachment);
        this.setAttachment(attachments);
    }
}
exports.EnergyBill = EnergyBill;
