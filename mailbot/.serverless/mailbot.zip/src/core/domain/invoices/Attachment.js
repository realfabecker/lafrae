"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Attachment = void 0;
const AbstractModel_1 = require("../common/AbstractModel");
const AttachmentObjectStorageKey_1 = require("../fields/AttachmentObjectStorageKey");
const date_fns_1 = require("date-fns");
class Attachment extends AbstractModel_1.AbstractModel {
    constructor(opts) {
        super(opts);
    }
    getId() {
        return this.get("id");
    }
    setId(id) {
        this.set("id", id);
    }
    getExternalId() {
        return this.get("externalId");
    }
    setExternalId(externalId) {
        this.set("externalId", externalId);
    }
    getName() {
        return this.get("name");
    }
    setName(name) {
        this.set("name", name);
    }
    getObjectUrl() {
        if (!this.get("objectUrl")) {
            const objectKey = AttachmentObjectStorageKey_1.AttachmentObjectStorageKey.new({
                attachment: this,
            }).getValue();
            this.setObjectUrl(objectKey);
        }
        return this.get("objectUrl");
    }
    setObjectUrl(name) {
        this.set("objectUrl", name);
    }
    getContentType() {
        return this.get("contentType");
    }
    setContentType(contentType) {
        this.set("contentType", contentType);
    }
    getContentEncoding() {
        return this.get("contentEncoding");
    }
    setContentEncoding(contentEncoding) {
        this.set("contentEncoding", contentEncoding);
    }
    getUserId() {
        return this.get("userId");
    }
    setUserId(userId) {
        this.set("userId", userId);
    }
    getCreatedAt() {
        return (0, date_fns_1.parseISO)(this.get("createdAt"));
    }
    setCreatedAt(createdAt) {
        if (createdAt instanceof Date) {
            this.set("createdAt", createdAt.toISOString());
        }
        else {
            this.set("createdAt", createdAt);
        }
    }
}
exports.Attachment = Attachment;
