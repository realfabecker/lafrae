"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnableToCreateInvoice = void 0;
class UnableToCreateInvoice extends Error {
    constructor() {
        super("Unable to Create Invoice");
    }
}
exports.UnableToCreateInvoice = UnableToCreateInvoice;
