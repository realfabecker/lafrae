"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrawlerDoesNotExists = void 0;
class CrawlerDoesNotExists extends Error {
    constructor(crawlerId) {
        super(`Crawler ${crawlerId} does not exists`);
    }
}
exports.CrawlerDoesNotExists = CrawlerDoesNotExists;
