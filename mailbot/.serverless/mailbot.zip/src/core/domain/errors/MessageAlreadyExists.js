"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageAlreadyExists = void 0;
class MessageAlreadyExists extends Error {
    constructor() {
        super("Message Already Exists");
    }
}
exports.MessageAlreadyExists = MessageAlreadyExists;
