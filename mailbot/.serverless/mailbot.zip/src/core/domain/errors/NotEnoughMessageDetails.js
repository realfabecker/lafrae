"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotEnoughtMessageDetails = void 0;
class NotEnoughtMessageDetails extends Error {
    constructor(messageId) {
        super(`mensagem ${messageId} com detalhes incompletos`);
    }
}
exports.NotEnoughtMessageDetails = NotEnoughtMessageDetails;
