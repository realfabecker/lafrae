"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnableToUploadObject = void 0;
class UnableToUploadObject extends Error {
    constructor() {
        super("Unable to Upload Object");
    }
}
exports.UnableToUploadObject = UnableToUploadObject;
