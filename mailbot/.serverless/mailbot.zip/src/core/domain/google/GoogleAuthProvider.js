"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleAuthProvider = void 0;
const AbstractModel_1 = require("../common/AbstractModel");
class GoogleAuthProvider extends AbstractModel_1.AbstractModel {
    constructor(opts) {
        super(opts);
    }
    setId(id) {
        this.set("id", id);
    }
    getId() {
        return this.get("id");
    }
    getAccessToken() {
        return this.get("accessToken");
    }
    getRefreshToken() {
        return this.get("refreshToken");
    }
    setAccessToken(accessToken) {
        this.set("accessToken", accessToken);
    }
    setRefreshToken(refreshToken) {
        this.set("refreshToken", refreshToken);
    }
    getUserId() {
        return this.get("userId");
    }
    setUserId(userId) {
        this.set("userId", userId);
    }
}
exports.GoogleAuthProvider = GoogleAuthProvider;
