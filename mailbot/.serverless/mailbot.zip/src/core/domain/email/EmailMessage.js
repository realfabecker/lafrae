"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailMessage = void 0;
const AbstractModel_1 = require("../common/AbstractModel");
class EmailMessage extends AbstractModel_1.AbstractModel {
    constructor(opts) {
        super(opts);
    }
    getId() {
        return this.get("id");
    }
    setId(id) {
        this.set("id", id);
    }
    getBody() {
        return this.get("body");
    }
    setBody(body) {
        this.set("body", body);
    }
    getAttachment() {
        return this.get("attachment") || [];
    }
    setAttachment(attachment) {
        this.set("attachment", attachment);
    }
    addAttachment(attachment) {
        const attachments = this.getAttachment() ?? [];
        attachments.push(attachment);
        this.setAttachment(attachments);
    }
}
exports.EmailMessage = EmailMessage;
