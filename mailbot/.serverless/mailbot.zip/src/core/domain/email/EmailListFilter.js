"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailListFilter = void 0;
const AbstractModel_1 = require("../common/AbstractModel");
class EmailListFilter extends AbstractModel_1.AbstractModel {
    constructor(opts) {
        super(opts);
    }
    getLabel() {
        return this.get("label");
    }
    setLabel(label) {
        this.set("label", label);
    }
    getIsUnread() {
        return this.get("isUnread");
    }
    setIsUnread(isUnread) {
        this.set("isUnread", isUnread);
    }
}
exports.EmailListFilter = EmailListFilter;
