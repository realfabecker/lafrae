"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailAttachment = void 0;
const AbstractModel_1 = require("../common/AbstractModel");
class EmailAttachment extends AbstractModel_1.AbstractModel {
    constructor(opts) {
        super(opts);
    }
    getId() {
        return this.get("id");
    }
    setId(id) {
        this.set("id", id);
    }
    getName() {
        return this.get("name");
    }
    setName(name) {
        this.set("name", name);
    }
    getBody() {
        return this.get("body");
    }
    setBody(body) {
        this.set("body", body);
    }
    getContentType() {
        return this.get("contentType");
    }
    setContentType(contentType) {
        this.set("contentType", contentType);
    }
    getContentEncoding() {
        return this.get("contentEncoding");
    }
    setContentEncoding(contentEncoding) {
        this.set("contentEncoding", contentEncoding);
    }
}
exports.EmailAttachment = EmailAttachment;
