"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageType = void 0;
var MessageType;
(function (MessageType) {
    MessageType["EnergyBill"] = "EnergyBill";
})(MessageType || (exports.MessageType = MessageType = {}));
