"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DomainError = void 0;
const AbstractModel_1 = require("./AbstractModel");
class DomainError extends AbstractModel_1.AbstractModel {
    constructor(opts) {
        super(opts);
    }
    getError() {
        return this.get("error");
    }
    setError(error) {
        this.set("error", error);
    }
    getDescription() {
        return this.get("description");
    }
    setDescription(description) {
        this.set("description", description);
    }
    getStatusCode() {
        return this.get("statusCode");
    }
    setStatusCode(statusCode) {
        this.set("statusCode", statusCode);
    }
    setDetails(details) {
        this.set("details", details);
    }
    getDetails() {
        return this.get("details");
    }
    getErrorDescription() {
        if (!this.getError() && !this.getDescription()) {
            return "Erro desconhecido";
        }
        if (this.getDetails() === "object") {
            return `${this.getError()}: ${this.getDescription()} : ${JSON.stringify(this.getDetails())}`;
        }
        if (this.getDescription()) {
            return `${this.getError()}: ${this.getDescription()}`;
        }
        return this.getError();
    }
}
exports.DomainError = DomainError;
