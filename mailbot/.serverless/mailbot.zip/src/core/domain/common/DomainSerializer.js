"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DomainSerializer = void 0;
const AbstractModel_1 = require("./AbstractModel");
class DomainSerializer {
    static serialize(r) {
        const data = {};
        const props = r instanceof AbstractModel_1.AbstractModel ? r.getData() : r;
        for (const [key, value] of Object.entries(props)) {
            if (value instanceof AbstractModel_1.AbstractModel) {
                data[key] = this.serialize(value);
            }
            else if (Array.isArray(value)) {
                data[key] = value.map((r) => this.serialize(r));
            }
            else {
                data[key] = value;
            }
        }
        return data;
    }
    static unserialize(model, data) {
        for (const key in data) {
            const setterName = "set" +
                key
                    .split("_")
                    .map((v) => v.charAt(0).toUpperCase() + v.slice(1))
                    .join("");
            const setterValue = data[key] instanceof AbstractModel_1.AbstractModel
                ? this.serialize(data[key])
                : data[key];
            if (typeof model[setterName] === "function") {
                model[setterName](setterValue);
            }
        }
        return model;
    }
}
exports.DomainSerializer = DomainSerializer;
