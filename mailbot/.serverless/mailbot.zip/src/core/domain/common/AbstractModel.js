"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbstractModel = void 0;
const DomainSerializer_1 = require("./DomainSerializer");
class AbstractModel {
    data = {};
    constructor(props) {
        if (props && Object.keys(props)) {
            DomainSerializer_1.DomainSerializer.unserialize(this, props);
        }
    }
    getData() {
        return this.data;
    }
    setData(data) {
        this.data = data;
    }
    set(key, val) {
        this.data[key] = val;
    }
    get(key) {
        return this.data[key];
    }
    serialize() {
        return DomainSerializer_1.DomainSerializer.serialize(this);
    }
}
exports.AbstractModel = AbstractModel;
