"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DomainResult = void 0;
const AbstractModel_1 = require("./AbstractModel");
const DomainError_1 = require("./DomainError");
class DomainResult extends AbstractModel_1.AbstractModel {
    constructor(opts) {
        super(opts);
    }
    static Ok(payload) {
        const result = new DomainResult();
        result.setSuccess(true);
        result.setPayload(payload);
        return result;
    }
    static Error(error) {
        const result = new DomainResult();
        result.setError(new DomainError_1.DomainError({ error: error.message }));
        result.setSuccess(false);
        return result;
    }
    setPayload(data) {
        this.set("payload", data);
    }
    getPayload() {
        return this.get("payload");
    }
    setError(error) {
        this.set("error", error);
    }
    getError() {
        if (!this.get("error")) {
            this.set("error", new DomainError_1.DomainError());
        }
        return this.get("error");
    }
    setSuccess(success) {
        this.set("success", success);
    }
    isSuccess() {
        return this.get("success");
    }
}
exports.DomainResult = DomainResult;
