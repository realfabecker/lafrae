"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProviderPattern = void 0;
const AbstractModel_1 = require("../common/AbstractModel");
class ProviderPattern extends AbstractModel_1.AbstractModel {
    constructor(opts) {
        super(opts);
    }
    getPattern() {
        return this.get("pattern");
    }
    setPattern(pattern) {
        this.set("pattern", pattern);
    }
    getProperty() {
        return this.get("property");
    }
    setProperty(property) {
        this.set("property", property);
    }
}
exports.ProviderPattern = ProviderPattern;
