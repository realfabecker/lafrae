"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageCrawler = void 0;
const AbstractModel_1 = require("../common/AbstractModel");
class MessageCrawler extends AbstractModel_1.AbstractModel {
    constructor(opts) {
        super(opts);
    }
    getId() {
        return this.get("id");
    }
    setId(id) {
        this.set("id", id);
    }
    getUserId() {
        return this.get("userId");
    }
    setUserId(userId) {
        this.set("userId", userId);
    }
    getAuthProvider() {
        return this.get("authProvider");
    }
    setAuthProvider(authProvider) {
        this.set("authProvider", authProvider);
    }
    getMessageType() {
        return this.get("messageType");
    }
    setMessageType(messageType) {
        this.set("messageType", messageType);
    }
    getProviderFilter() {
        return this.get("providerFilter");
    }
    setProviderFilter(providerFilter) {
        this.set("providerFilter", providerFilter);
    }
    getProviderPattern() {
        return this.get("providerPattern");
    }
    setProviderPattern(providerPattern) {
        this.set("providerPattern", providerPattern);
    }
}
exports.MessageCrawler = MessageCrawler;
