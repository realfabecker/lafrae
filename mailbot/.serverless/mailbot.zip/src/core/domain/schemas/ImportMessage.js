"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImportMessage = void 0;
const zod_1 = require("zod");
exports.ImportMessage = zod_1.z.object({
    meta: zod_1.z.object({
        type: zod_1.z.string(),
    }),
    data: zod_1.z.object({
        messageId: zod_1.z.string(),
    }),
});
