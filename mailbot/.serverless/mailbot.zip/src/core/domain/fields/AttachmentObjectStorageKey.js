"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AttachmentObjectStorageKey = void 0;
const node_path_1 = __importDefault(require("node:path"));
class AttachmentObjectStorageKey {
    value;
    constructor(value) {
        this.value = value;
    }
    static new({ attachment }) {
        const key = [
            "attachments",
            attachment.getUserId(),
            attachment.getCreatedAt().getFullYear(),
            attachment.getCreatedAt().getMonth(),
            `${attachment.getId()}${node_path_1.default.extname(attachment.getName())}`,
        ];
        return new AttachmentObjectStorageKey(key.join("/"));
    }
    getValue() {
        return this.value;
    }
}
exports.AttachmentObjectStorageKey = AttachmentObjectStorageKey;
